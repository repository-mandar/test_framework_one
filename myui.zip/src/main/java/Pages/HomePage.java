package Pages;

import Base.Base;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends Base {

    @FindBy(xpath="//input[@id='searchInput']")
    @CacheLookup
    WebElement searchbar;

    @FindBy(xpath="//a[@id='myStatusCardItemLink0']")
    private WebElement firstticketinmystatus;

    @FindBy(xpath="//a[@id='myStatusCardViewAllLink']")
    private WebElement viewalllink;

    public HomePage(){
        PageFactory.initElements(driver,this);
    }

    public void searchFromHomePage(){
        searchbar.click();
        searchbar.sendKeys("Password issue");
    }
}
