package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class Base {

     public static WebDriver driver;
     public static Properties pro;

   public Base() {
//        pro = new Properties();
//        try {
//            FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + "Config/Config.properties");
//            pro.load(fileInputStream);
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
    }

    public static void startdriver(){
        //String BrowserName = pro.getProperty("browser");

        if(true){
            System.setProperty("webdriver.chrome.driver","C:\\UBS\\Dev\\softwares\\chromedriver.exe");
            driver = new ChromeDriver();
        }
        else if(true){
        }
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("https://myhub.ubsdev.net/myhub/");
    }

    public static void closeBrowser(){
       driver.quit();
    }
}