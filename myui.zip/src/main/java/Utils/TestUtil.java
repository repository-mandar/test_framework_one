package Utils;

import Base.Base;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import java.io.File;
import java.util.Set;

public class TestUtil extends Base {
    public static String getScreenshot(){
        String path=null;
        try {
            File newfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            int i =1;
            String userDirPath = System.getProperty("user.dir");
            File destfile = new File(userDirPath + "/screenshot/"+"SeleniumScreenshot" +System.currentTimeMillis()+ ".png");
            path = destfile.toString();
            FileUtils.copyFile(newfile, destfile);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return path;
    }

    public static void scrollToelement(WebElement element){
        Actions action = new Actions(driver);
        action.moveToElement(element).build().perform();
    }

    public static void moveToEndToPage() throws Exception {
        Actions action = new Actions(driver);
        String a = "k0023";
        Thread.sleep(5000);
        //action.keyDown(Keys.CONTROL).sendKeys("END").keyUp(Keys.CONTROL).perform();
        action.sendKeys(Keys.PAGE_DOWN);
    }

    //Open browser new tab

    public static void openNewTab(){

        String currentWindowhandle = driver.getWindowHandle();
        ((JavascriptExecutor) driver).executeScript("window.open('about:blank','_blank');");
        Set <String> handles = driver.getWindowHandles();
        System.out.println("Handles now ---->" + handles);

        driver.switchTo().window(currentWindowhandle);
        for(String handle : handles){

        }
    }
}
