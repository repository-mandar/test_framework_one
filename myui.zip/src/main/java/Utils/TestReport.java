package Utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.testng.ITestResult;

public class TestReport {

    static ExtentReports reports;
    static ExtentTest logger;

    public static void startTest(){
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("C:\\Users\\t618245\\IdeaProjects\\uiauto\\src\\test\\resources\\Screenshots\\MyETReport.html");
        reports = new ExtentReports();
        reports.attachReporter(htmlReporter);

        logger =reports.createTest("My ExtentReport Test");
    }
        String temppath = TestUtil.getScreenshot();

    public static void generateReport(ITestResult result){

        logger.log(Status.PASS, MarkupHelper.createLabel("Test Case Passed is passTest", ExtentColor.GREEN));
        if(result.getStatus() == ITestResult.SUCCESS){
            System.out.println("+++++++++++++++++++++++++++++++Test Is Passed+++++++++++++++++++++++++++++++++++++++++++++++");
        }
        else{
            System.out.println("Test Is Failed");
        }

        reports.flush();
    }
}
