package Utils;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.testng.annotations.DataProvider;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

public class ReadWriteDataFromExcel {

    static HSSFWorkbook workbook;
    static HSSFSheet sheet;
    static File file;
    static String filepath ="C:\\UBS\\Dev\\Excels\\Tasks_sheet1.xls";

@DataProvider
    public static Object[][] getDataFromSheet()throws Exception{
        file = new File(filepath);
        FileInputStream fis = new FileInputStream(file);
        workbook= new HSSFWorkbook(fis);
        sheet = workbook.getSheet("Jira_Cards");

            HSSFRow row = sheet.getRow(0);
           //Traverse using for loop and one row at a time.
            int rowno = sheet.getPhysicalNumberOfRows();
            int colno = row.getLastCellNum();
           Object [][] data = new Object[rowno][colno];

           for(int i= 0;i<rowno;i++){

               HSSFRow onerowattime = sheet.getRow(i);

               for(int j =0;j<colno;j++) {
                   if (onerowattime == null) {
                       data[i][j] = "";
                   } else {
                       Cell celldata = onerowattime.getCell(j);
                       if(celldata== null)
                           data[i][j]="";
                       else {
                           String cellvalueasstring = celldata.toString();
                           System.out.print(cellvalueasstring);
                           data[i][j] = cellvalueasstring;
                           System.out.print(data[i][j]);
                       }
                   }
               }
                System.out.println();
           }
        return data;

            // Iterate whole sheet using iterator interface

            /*Iterator <Row> rowiterator = sheet.rowIterator();

            while(rowiterator.hasNext()){

                Row row = rowiterator.next();
                //System.out.print(row.toString());
                Iterator <Cell> cellIterator = row.cellIterator();

                while (cellIterator.hasNext()){
                Cell cell1 = cellIterator.next();
                System.out.print(cell1);

            }
            System.out.println();
        }*/

        // Traversing of sheet using for each loop

            /*
            for (Row row:sheet){
                for(Cell cell: row){
                    System.out.println(cell.toString());
                }
            }*/


        }
}
