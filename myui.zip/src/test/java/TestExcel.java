import Utils.ReadWriteDataFromExcel;
import org.testng.annotations.Test;

public class TestExcel {
    @Test()
    void calltodata() throws Exception {
        ReadWriteDataFromExcel.getDataFromSheet();
    }

    @Test(dataProvider = "getDataFromSheet",dataProviderClass = ReadWriteDataFromExcel.class)
    void testdataprovider(String a,String b,String c,String d,String e,String f,String g,String h,String i,String j,String k,String l,String m,String n,String o,String p){

        System.out.println("Data from data provider  --->>>"+a+"======================================================\n"+"Data from second column --->>> "+b+"========================================================\n");
    }

}
