import Base.Base;
import Pages.HomePage;
import Utils.TestReport;
import Utils.TestUtil;
import org.testng.*;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.Set;

public class TestHomePage extends Base {
    HomePage homePage;


    @BeforeMethod
    public void setup(){
        Base.startdriver();
        homePage= new HomePage();
        TestReport.startTest();
    }
    @Test
    public void searchArticle(){
        homePage.searchFromHomePage();
        Assert.assertTrue(true);
    }
    @AfterMethod
    public void tearDown(ITestResult result){
        TestReport.generateReport(result);
        if(result.getStatus() == ITestResult.SUCCESS){
            System.out.println("Test Is Passed"+result);
        }
        else{
            System.out.println("Test Is Failed");
        }
        TestUtil.closeBrowser();
    }
}
