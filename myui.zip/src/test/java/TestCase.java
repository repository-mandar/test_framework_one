import Base.Base;
import Utils.TestUtil;
import org.testng.annotations.Test;

import java.awt.*;

public class TestCase extends Base {

    @Test
    public void example() throws Exception {

        Base.startdriver();
        //TestUtil.moveToEndToPage();
        TestUtil.getScreenshot();
        //Base.closeBrowser();

    }
}
